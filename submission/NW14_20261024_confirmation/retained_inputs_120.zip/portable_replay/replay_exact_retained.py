"""Replay immutable RAES against all retained Hybrid and Q-neutral snapshots."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import numpy as np
from test_exact_planner import plan,SOURCE,SHA
OUT=Path(__file__).resolve().parent
REG=OUT/'REGISTRY_120.csv'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
with REG.open(encoding='utf-8-sig',newline='') as f:registry=list(csv.DictReader(f))
counts=Counter();issues=[];cases=[];manifest={str(SOURCE):SHA,str(REG):sha(REG)};max_pressure_error=0.
for row in registry:
    if row['method'] not in ('actuation_hybrid','actuation_qneutral'):continue
    n=OUT/Path(row['evidence_folder'])/'native';ds=lines(n/'decisions.jsonl');obs={}
    local_source=n/'policy/sources/candidate_sources/raes.py'
    assert sha(local_source)==SHA
    for p in [local_source,n/'decisions.jsonl',n/'stdout.log']:manifest[str(p)]=sha(p)
    for line in (n/'stdout.log').read_text().splitlines():
        if line.startswith('THREEWAY_OBS '):
            o=json.loads(line.split(' ',1)[1]);obs[o['epoch']]=o
    previous_current=previous_action=None
    for d in ds:
        nodes=obs[d['epoch']]['nodes'];e=d['policy_evidence'];nn=len(nodes)
        powers=np.array([v['powersW'] for v in nodes]).reshape(nn,nn,4)
        coupling=(powers/powers[np.arange(nn),np.arange(nn)][:,None,:]).mean(-1);np.fill_diagonal(coupling,0.)
        loads=np.array([v['nominalMbps'] for v in nodes])/54.;ahat=coupling*loads[None,:]
        # The adapter recovers coupling from ahat/loads before thresholding.
        recovered=ahat/loads[None,:];graph=np.maximum(recovered,recovered.T)>=.01;np.fill_diagonal(graph,False)
        current=np.array([v['channel'] for v in nodes],dtype=int)
        movable=np.ones(nn,dtype=bool) if previous_current is None else ~((previous_action!=previous_current)&(current!=previous_action))
        q=np.array(e['q']);planning_q=np.zeros_like(q) if e['q_neutral'] else q
        action,trace=plan(planning_q,current,ahat,np.arange(nn),capture_trace=True,conflict_graph=graph,movable=movable,q_budget=e['q_budget'],**e['coefficients'])
        checks=dict(action=action.tolist()==d['channels'],reservation_order=[v['node'] for v in trace]==e['reservation_order'],
                    graph=np.argwhere(np.triu(graph,1)).tolist()==e['graph_edges'])
        choices=[]
        pressure=ahat@np.eye(4)[current]
        for t in trace:
            i=t['node'];remaining=t['remaining'];chosen=int(action[i])
            choices.append(dict(node=i,allowed=t['allowed'],selected=chosen,**{key:t[key] for key in ['forced_feasibility','no_available_channel','gate_blocked','mask_overridden_by_gate']}))
            if chosen!=current[i]:pressure[remaining,current[i]]-=ahat[remaining,i];pressure[remaining,chosen]+=ahat[remaining,i]
            error=float(np.max(abs(pressure[remaining]-t['pressure']))) if remaining else 0.
            max_pressure_error=max(max_pressure_error,error)
        checks['choices_and_precedence']=choices==e['choices']
        checks['pressure_updates']=max_pressure_error==0.
        for field,tracefield in [('forced_feasibility_count','forced_feasibility'),('no_available_channel_count','no_available_channel'),('gate_blocked_count','gate_blocked'),('gate_mask_override_count','mask_overridden_by_gate')]:
            checks[field]=sum(bool(t[tracefield]) for t in trace)==e[field]
        for check,ok in checks.items():
            if not ok:issues.append(dict(method=row['method'],condition=row['condition'],load=row['load_mbps_per_sta'],seed=row['seed'],epoch=d['epoch'],check=check))
        previous_current,previous_action=current,action
        counts[row['method'],'epochs']+=1;counts[row['method'],'node_choices']+=nn
    assert len(ds)==len(obs)==13
    counts[row['method'],'runs']+=1
    cases.append(dict(method=row['method'],condition=row['condition'],load=row['load_mbps_per_sta'],seed=row['seed'],epochs=len(ds)))
result=dict(status='PASS' if not issues else 'FAIL',methods={m:{key:v for (method,key),v in counts.items() if method==m} for m in sorted({k[0] for k in counts})},
    issues=issues,max_pressure_update_error=max_pressure_error,source=str(SOURCE),source_sha256=SHA,cases=cases,
    scope='Actual frozen plan invoked on every retained Hybrid and Q-neutral epoch, using recorded Q and causal snapshot-derived coupling/current/load; gate reconstructed from previous intended/current actions. Graph/order/action/all choice flags and reserve pressure checked. No new model inference or native execution.')
(OUT/'EXACT_REPLAY_RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(OUT/'EXACT_REPLAY_INPUT_SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2));assert not issues
