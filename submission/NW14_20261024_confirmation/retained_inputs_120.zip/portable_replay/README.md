# Portable retained planner verification

Python3.9+ and NumPy are required. No PyTorch, model inference, native simulator, build or training is invoked. From this directory:

```
python test_exact_planner.py
python replay_exact_retained.py
```

Expected:18tests PASS; Hybrid60runs/780epochs/11700nodechoices and Q-neutral60runs/780epochs/11700nodechoices, no replay discrepancies and zero pressure update error.

The source is the exact historical RAES file with SHA256cfea06e17708e74422fc35606d1a2fd1c88c1078d3de04c7d03427bbeae1854a. The test/replay harness only relocates source and input paths; expected outputs and scientific arithmetic remain unchanged. The registry contains120historical recorded runs, not120new experiments. Recorded Q values are replayed, not re-inferred.

This verifies controller behavior on supplied observations. It does not establish clean ns-3 build reproducibility, new service performance, generalization, physical cancellation or independent external authentication. Input receipts keep historical absolute paths as provenance; the executable verification commands use the relative export layout.
