"""Offline calls to immutable archived RAES; no policy copies, native, or model calls."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
sys.dont_write_bytecode = True
import numpy as np

OUT = Path(__file__).resolve().parent
SOURCE = Path(__file__).resolve().parent/'source/raes.py'
SHA = 'cfea06e17708e74422fc35606d1a2fd1c88c1078d3de04c7d03427bbeae1854a'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SHA
spec = importlib.util.spec_from_file_location('frozen_raes', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
plan = module.plan

class ExactPlanner(unittest.TestCase):
    def run_plan(self, q, current, a=None, ids=None, **kw):
        q=np.array(q,dtype=float);n=len(q)
        return plan(q,np.array(current,dtype=int),np.zeros((n,n)) if a is None else a,
                    np.arange(n) if ids is None else np.array(ids,dtype=int),pref=1.,capture_trace=True,**kw)

    def test_uniform_q_and_no_edges_keep_current(self):
        action,trace=self.run_plan([[7,7],[7,7]],[0,1],conflict_graph=np.zeros((2,2)))
        self.assertEqual(action.tolist(),[0,1]);self.assertEqual([x['node'] for x in trace],[0,1])
        self.assertFalse(any(x['no_available_channel'] for x in trace))

    def test_pressure_order_then_ap_identity(self):
        action,trace=self.run_plan([[0,0],[0,0],[0,0]],[0,0,0],
            a=np.array([[0,1,0],[1,0,0],[0,0,0.]]),ids=[20,10,0])
        self.assertEqual([x['node'] for x in trace],[1,0,2])

    def test_tie_current_has_priority_over_channel_number(self):
        action,_=self.run_plan([[1,1,1]],[2]);self.assertEqual(action.tolist(),[2])

    def test_tie_lower_channel_when_current_not_best(self):
        action,_=self.run_plan([[0,1,1]],[0]);self.assertEqual(action.tolist(),[1])

    def test_exact_gain_equal_delta_holds(self):
        action,_=self.run_plan([[0,1]],[0],q_budget=.5,delta=.5)
        self.assertEqual(action.tolist(),[0])

    def test_gain_just_above_delta_moves(self):
        action,_=self.run_plan([[0,1]],[0],q_budget=.5,delta=np.nextafter(.5,0.))
        self.assertEqual(action.tolist(),[1])

    def test_current_disallowed_bypasses_hysteresis(self):
        action,trace=self.run_plan([[0,0],[0,0]],[0,0],conflict_graph=np.array([[0,1],[1,0]]),delta=100.)
        self.assertEqual(action.tolist(),[0,1]);self.assertEqual(trace[1]['allowed'],[1])
        self.assertTrue(trace[1]['forced_feasibility'])

    def test_gate_conflict_overrides_mask_and_hysteresis(self):
        action,trace=self.run_plan([[0,0],[0,0]],[0,0],conflict_graph=np.array([[0,1],[1,0]]),
            movable=np.array([True,False]),delta=100.)
        self.assertEqual(action.tolist(),[0,0]);self.assertTrue(trace[1]['mask_overridden_by_gate'])
        self.assertTrue(trace[1]['gate_blocked']);self.assertFalse(trace[1]['forced_feasibility'])

    def test_clique_exhausts_four_channels_then_empty_mask_fallback(self):
        graph=np.ones((5,5),dtype=bool);np.fill_diagonal(graph,False)
        action,trace=self.run_plan(np.zeros((5,4)),[0]*5,conflict_graph=graph)
        self.assertEqual(action.tolist(),[0,1,2,3,0])
        self.assertEqual(trace[-1]['allowed'],[0,1,2,3]);self.assertTrue(trace[-1]['no_available_channel'])
        self.assertFalse(trace[-1]['forced_feasibility'])

    def test_empty_mask_is_fallback_then_gate(self):
        graph=np.ones((3,3),dtype=bool);np.fill_diagonal(graph,False)
        action,trace=self.run_plan([[0,0],[0,0],[0,1]],[0,0,0],conflict_graph=graph,movable=np.array([True,True,False]))
        self.assertEqual(action.tolist(),[0,1,0]);self.assertTrue(trace[-1]['no_available_channel'])
        self.assertTrue(trace[-1]['gate_blocked']);self.assertFalse(trace[-1]['mask_overridden_by_gate'])

    def test_reservation_updates_receiver_row_transmitter_column(self):
        a=np.array([[0,2.],[3.,0]])
        action,trace=self.run_plan(np.zeros((2,2)),[0,0],a=a)
        self.assertEqual([x['node'] for x in trace],[1,0]);self.assertEqual(action.tolist(),[0,1])
        np.testing.assert_array_equal(trace[0]['pressure'],[[0.,2.]])

    def test_gate_held_node_does_not_reserve_proposed_move(self):
        action,trace=self.run_plan(np.zeros((2,2)),[0,0],a=np.array([[0,2.],[3.,0]]),movable=np.array([True,False]))
        self.assertEqual(action.tolist(),[1,0]);np.testing.assert_array_equal(trace[0]['pressure'],[[2.,0.]])

    def test_switch_cost_precedes_hysteresis(self):
        action,_=self.run_plan([[0,1]],[0],q_budget=.5,mu=.25,delta=.25)
        self.assertEqual(action.tolist(),[0])

    def test_epsilon_q_and_zero_budget(self):
        action,_=self.run_plan([[0,1e-7]],[0],epsilon_q=1e-6,delta=.1)
        self.assertEqual(action.tolist(),[0])
        action,_=self.run_plan([[0,1]],[0],q_budget=0.);self.assertEqual(action.tolist(),[0])

    def test_nonfinite_scalar_and_matrix_boundaries(self):
        for val in [np.nan,np.inf,-np.inf]:
            for name in ['pref','eta','lam','mu','delta','epsilon_q','q_budget']:
                with self.subTest(name=name,value=str(val)), self.assertRaises(ValueError):
                    args=dict(pref=1.);args[name]=val
                    plan([[0,1]],np.array([0]),[[0]],np.array([0]),**args)
            with self.subTest(matrix='Q',value=str(val)),self.assertRaises(ValueError):self.run_plan([[0,val]],[0])
            with self.subTest(matrix='ahat',value=str(val)),self.assertRaises(ValueError):self.run_plan([[0,1],[0,1]],[0,0],a=[[0,val],[0,0]])

    def test_nonfinite_intermediate_rejected(self):
        with self.assertRaisesRegex(ValueError,'nonfinite intermediate'):
            self.run_plan([[-1e308,1e308]],[0])

    def test_invalid_mask_gate_and_identity_rejected(self):
        for kw in [dict(conflict_graph=[[0,1],[0,0]]),dict(conflict_graph=[[1,0],[0,0]]),
                   dict(conflict_graph=[[0,np.nan],[np.nan,0]]),dict(movable=[1,0]),dict(ids=[0,0])]:
            with self.subTest(kw=str(kw)),self.assertRaises(ValueError):self.run_plan([[0,1],[1,0]],[0,0],**kw)

    def test_no_input_mutation_and_trace_disabled_same_action(self):
        q=np.array([[1.,0],[0.,1]]);a=np.array([[0.,2],[3.,0]]);current=np.array([0,0]);ids=np.array([3,2])
        originals=[x.copy() for x in [q,a,current,ids]]
        first,_=plan(q,current,a,ids,pref=1.,capture_trace=True)
        second,trace=plan(q,current,a,ids,pref=1.)
        np.testing.assert_array_equal(first,second);self.assertEqual(trace,[])
        for old,new in zip(originals,[q,a,current,ids]):np.testing.assert_array_equal(old,new)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ExactPlanner))
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SHA
    (OUT/'EXACT_PLANNER_RESULT.json').write_text(json.dumps(dict(status='PASS' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,
        failures=len(result.failures),errors=len(result.errors),source=str(SOURCE),source_sha256=SHA,
        scope='Actual archived pure RAES plan calls; no native actuator or trained GAT inference executed.'),indent=2),encoding='utf-8')
    raise SystemExit(not result.wasSuccessful())
